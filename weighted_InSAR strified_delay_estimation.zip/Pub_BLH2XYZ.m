%% Transforming Geodetic Coordinates to Cartesian Coordinates
function [X,Y]= Pub_BLH2XYZ(B,L)
%%
%	Input: 
%			Geodetic Coordinates system: 
%					Geodetic latitude(rad):				B
%					Geodetic longitude(rad):			L
%					Geodetic Height(m):					H
%	Output:
%			Cartesian Coordinates system: 
%					X Direction(m):						X
%					Y Direction(m):						Y
%					Z Direction(m):						Z
%	Reference:
%			[1] KONG Xiangyuan, GUO Jiming, LIU Zongquan. Foundation of GEOdesy[M](in Chinese). 2nd ed. Wuhan: Wuhan University Press, 2010.
%	Date:	2021/10/30	By Jianhua Chen

%%
	SINB = sind(B);
	COSB = cosd(B);
	COSL = cosd(L);
	SINL = sind(L);
	W = sqrt(1.0 - 0.00669437999013.*SINB.*SINB);
    clear SINB
	N = 6370.856./W;
	X = N.*COSB.*COSL;
	Y = N.*COSB.*SINL;
    clear COSB COSL SINL N
	%Z = (N*(1.0 - EllipsoidPara.E2) + H)*SINB;
end