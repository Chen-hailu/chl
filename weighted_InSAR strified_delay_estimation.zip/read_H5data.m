%% read Mintpy outputs of time series from HDF5 file in Matlab 
function [phase,longitude1,latitude1,height1]= read_H5data(ts_file,s)
% phase,longitude1,latitude1,height1����λʱ�����У����ȣ�γ�ȣ��߳�
geo_file = 'geometryRadar.h5';
%% Read geo file
h5disp(geo_file)
% read the whole time-series into one 3D matrix
latitude= h5read(geo_file, '/latitude');
longitude = h5read(geo_file, '/longitude');
spa_r      = h5readatt(geo_file,'/','RANGE_PIXEL_SIZE');             spa_r      = str2double(spa_r);
spa_azi    = h5readatt(geo_file,'/','AZIMUTH_PIXEL_SIZE');           spa_azi    = str2double(spa_azi);
wavelen    = h5readatt(geo_file,'/','WAVELENGTH');                   wavelen    = str2double(wavelen);
width      = h5readatt(geo_file,'/','WIDTH');                        width      = str2double(width);
lines      = h5readatt(geo_file,'/','LENGTH');                        lines      = str2double(lines);
height = h5read(geo_file, '/height');
incangle_all= h5read(geo_file, '/incidenceAngle');
HEADING=h5readatt(geo_file,'/','HEADING');
HEADING=str2double(HEADING);
height1=rot90(height,s);
longitude1=rot90(longitude,s);
latitude1=rot90(latitude,s);
incangle_all1=rot90(incangle_all,s);
clear height incangle_all latitude longitude
%% create data matrix
mask_file = 'maskTempCoh.h5';
% Read time-series file
h5disp(mask_file)
mask_data = h5read(mask_file, '/mask');
mask_data1=ones(size(mask_data,1),size(mask_data,2));
for i=1:size(mask_data,1)
    for j=1:size(mask_data,2)
        if strcmp(mask_data{i,j},'FALSE')
            mask_data1(i,j)=0;
        end
    end
end
mask_data2=rot90(mask_data1,s);
clear mask_data mask_data1

longitude1=longitude1.*mask_data2;
latitude1=latitude1.*mask_data2;
incangle_all1=incangle_all1.*mask_data2;
height1=height1.*mask_data2;
% Read time-series file
h5disp(ts_file)
% read the whole time-series into one 3D matrix
date_list = h5read(ts_file, '/date');
ts_data = h5read(ts_file, '/timeseries');

for i=1:size(date_list,1)
    A=ts_data(:,:,i).*100;
    B=rot90(A,s);
    phase(:,:,i)=B.*mask_data2;
end

height1=height1.*mask_data2;
longitude1=longitude1.*mask_data2;
latitude1=latitude1.*mask_data2;


height1(height1 == 0) = NaN;
longitude1(longitude1 == 0) = NaN;
latitude1(latitude1 == 0) = NaN;
phase(phase == 0) = NaN;
phase(:,:,1)=0;

end
