function [ Str_correction]=calculate_correction_timeseries(par_weight,height1,order)

Str_correction=zeros(size(height1,1),size(height1,2),size(par_weight,1)+1);
Str_correction(:,:,1)=0;

 if order==1
     for i=2:size(par_weight,1)+1
     cc= par_weight(i-1,1);
     Str_correction(:,:,i)=Str_correction(:,:,i-1)+ height1.*cc;
    end

 end


if order==2
     for i=2:size(par_weight,1)+1
     cc1= par_weight(i-1,1);
     cc2= par_weight(i-1,2);
     Str_correction(:,:,i)=Str_correction(:,:,i-1)+ height1.*cc1+ height1.*height1.*cc2;
    end

 end


 if order==3
     for i=2:size(par_weight,1)+1
     cc1= par_weight(i-1,1);
     cc2= par_weight(i-1,2);
     cc3= par_weight(i-1,3);
     Str_correction(:,:,i)=Str_correction(:,:,i-1)+ height1.*cc1+ height1.*height1.*cc2+ height1.*height1.*height1.*cc3;
    end

 end


end