function [e_a,e_b]=Gauss1(dee,D_ew_n11)

%% 方差不整体估，直接采用观测量，只估相关距离
D_ew_0=D_ew_n11(1,1);
D_ew_n11_0=D_ew_n11(1:end,1);
vv=dee(1,1:end);
be=(-1)*(vv');
%  be=[ones(nsege+1,1) (-1)*(dee')];
%  bn=[ones(nsegn+1,1) (-1)*(dnn')];
logDe=(log(D_ew_n11_0)-log(D_ew_0));            %MATLAB中：log()表示ln()；log10()表示lg()。
%logDe=log(D_ew_n11_0);
% %最小二乘求系数2x1         
parae=pinv(be'*be)*be'*logDe; 
e_a=D_ew_0;
e_b=parae(1,1);
dee1=0:1:30;
Dmodel=e_a*exp((-1)*e_b*dee);
dee1=dee1';
Dmodel1=Dmodel';
%plot(dee,[Dmodel1 D_ew_n11])
end