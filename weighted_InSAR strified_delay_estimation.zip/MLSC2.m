function [e_a1,e_b1,D_SS_ew1] = MLSC2(vee,DS,Number_segments)
%% 随机模型拟合空间自相关变量包（written by Hailu Chen email:2210929@tongji.edu.cn）
%% 该版本只具备拟合功能，不具备推估插值功能，输入数据为位置，相位向量，MLSC1只实现构建观测量协方差矩阵部分
%% 输出数据为，e_a1和e_b1为协方差函数参数；Sppne1为拟合相位；misfit1和coeff1为协方差函数拟合误差和相关系数；Residual1为相位拟合残差
% longitude= lon2;%经度，单位度
% latitude= lat2; %纬度，单位度
 [spn,~]=size(vee);
 vee=vee-mean(vee);
DS=real(DS);%取实数值
dmax=max(max(DS));%所有点对所对应距离中距离最长值，即所有测站中相距最远的的距离的值
%协方差函数拟合
%求解距离为零时的信号与噪声的方差均值
vee_2=vee.^2;
D_ew_0=sum(vee_2)/spn;%东向残差（剩余速度）方差均值
clear vee_2

DS0=dmax./Number_segments;%计算分段统计间距
seg_dis=DS0;

nseg=floor(dmax/DS0);  %floor向小取整，ceil向大取整，round四舍五入取整
S =vee*vee';
 D_ew_n=zeros(nseg,1);
for k=0:nseg-1
    A=sum(S(DS>k*seg_dis&DS<=(k+1)*seg_dis));
    %part_muber=part_muber+1;
    segn(k+1)=length(find(DS>k*seg_dis&DS<=(k+1)*seg_dis));
    D_ew_n(k+1,1)=A/segn(k+1);
    distance(k+1,:)=[k*seg_dis (k+1)*seg_dis];

end

b=round(0.3*Number_segments);
%% 剔除最后20段不可靠结果
 D_ew_n(end-b:end,:)=[];
 distance(end-b:end,:)=[];
 VV=find(D_ew_n<0);
 IF=isempty(VV);
% % signal2(VV(1,1)-3:end,1)=0;
if IF==0
 D_ew_n(VV(1,1):end,:)=[];
 distance(VV(1,1):end,:)=[];
end
clear A S

%%
pp=find(D_ew_n>0);
nsege=size(pp,1);%协方差均值大于零的距离段的个数

%以下用于最小二乘求解系数
%D_ew_n11=[D_ew_0;D_ew_n(1:nsege)];%行向量，分别为：方差均值，筛选出来的协方差均值（即按距离分布的协方差均值，d=0的协方差是方差）——东向
D_ew_n11(1,1)=D_ew_0;%
dee(1,1)=0;

for i=1:nsege
D_ew_n11(1+i,1)=D_ew_n(pp(i,1),1);
Distance(i,:)=distance(pp(i,1),:);
dee(1,i+1)=mean(Distance(i,:));
end

clear  D_ew_n
%利用上述统计得到各个分段的协方差，拟合协方差函数，获得相应参数
%生成等间距的数组
%linspace（X1，X2，N）用于产生X1，X2之间的N点行矢量，相邻数据跨度相同。其中X1，X2，N分别为起始值、终止值、元素个数。若缺省N，默认点数为100
% de=linspace(seg_dis,nsege*seg_dis,nsege);%——东向
% dee=[0 de-seg_dis/2];
% clear de
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%初始用于拟合高斯函数的协方差阵构造完成%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%拟合高斯协方差函数%%%%%%%%%%%%%%%%
%% 关键步骤----经验协方差函数拟合
[e_a1,e_b1]=Gauss1(dee,D_ew_n11);
if e_b1==0
   e_b1=0.00000000001;
end
%利用拟合的协方差函数重新获得已测点信号协方差矩阵D_SS_ew和D_SS_sn
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%高斯函数拟合完后%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%按最小二乘配置法求解欧拉参数和信号值，并验证其合理性%%%%%%%
 D_SS_ew1=e_a1*exp((-1)*e_b1.*DS);
 
 s=eig(D_SS_ew1);

 if min(s)<0
 [V,D]=eig(D_SS_ew1);
d=diag(D);
d(d<1e-7)=1e-7;
D1=diag(d);
D_SS_ew1=V*D1*V';
D_SS_ew1=(D_SS_ew1+D_SS_ew1')/2;
 clear DS D_ew_n11 D1 V D
 end
  clear DS D_ew_n11
 end
