function [par2,par0]=Par_estimation(y,dem,DS,Number_segments,order)
    Y=[y(:) dem(:)];
    Y(any(isnan(Y),2),:) = [];
    Y=double(Y);
    DS=double(DS);
   if order==1
     hgt=Y(:,2);
   end
   if order==2
     hgt=[Y(:,2) Y(:,2).*Y(:,2)];
   end

    par0=lsmr(hgt,Y(:,1))
    [e_a1,e_b1,D_SS_ew1] = MLSC2(Y(:,1)-hgt*par0,DS,Number_segments);
    par1= lscov(hgt,Y(:,1),D_SS_ew1)
    clear D_SS_ew1 
    [e_a2,e_b2,D_SS_ew2] = MLSC2(Y(:,1)-hgt*par1,DS,Number_segments);
    par2= lscov(hgt,Y(:,1),D_SS_ew2)
    clear D_SS_ew12
    par2=par2';
    par0=par0';

end